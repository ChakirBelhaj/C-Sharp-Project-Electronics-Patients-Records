%% readme.txt
%% voor EPD-Simulator (version 1.00)

Naam:-         FireFly
Auteurs:-       Chakir   (s1116938@student.windesheim.nl)
		Mouaad   (s1116269@student.windesheim.nl)
		Laurence (s1116426@student.windesheim.nl)
Date:-          April 15, 2018

(1) INTRODUCTIE
-----------------
Een EPD simulator die toegepast kan worden in het lab van verpleegkunde binnen Windesheim Flevoland waarmee studenten effectief het gebruik van het EPD binnen het zorgproces onderwezen kan worden. 


(2) SYSTEEM EISEN
--------------------
Deze applicatie functioneert op alle besturing-systemen met de ondersteunin van .NET versie 3.0 of hoger 



(4) PACKAGES & FILES
------------------
De volgende bestanden staan in de EPD-Simulator pakket.


EpdFirefly.exe        			
EpdFirefly.exe.config              
EpdFirefly.pdb       
MaterialDesignColors.dll          
MaterialDesignThemes.Wpf.dll            
MaterialDesignThemes.Wpf.pdb           
MaterialDesignThemes.Wpf.xml          
MySql.Data.dll    		 
MySql.Data.xml    		
Renci.SshNet.dll   
Renci.SshNet.xml          
System.Buffers.dll            
System.Threading.Tasks.Extensions.dll       
System.Threading.Tasks.Extensions.xml      


(6) USAGE  (see manual for full details)

(7) LICENSE (LPPL):
-------------
Deze software is alleen bedoeld voor educationele doeleinden.
-----------------
End of README.txt
-----------------


=========================
